@extends('layout.admin-dashboard-layout')
@section('pageTitle', isset($pageTitle) ? $pageTitle : 'Dashboard :: Computer Based Test')
@section('content')
    content here
@endsection